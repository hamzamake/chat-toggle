package com.togglechat;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public class ToggleChatMod implements ClientModInitializer {
    
    public static boolean chatVisible = true;
    
    private static class_304 toggleChatKey;
    
    @Override
    public void onInitializeClient() {
        // Register the keybind (default: H key)
        // In 1.21.11 Yarn mappings, KeyBinding constructor takes:
        // (String id, int code, KeyBinding.Category category)
        toggleChatKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.togglechat.toggle",
            GLFW.GLFW_KEY_H,
            class_304.class_11900.field_62556
        ));
        
        // Listen for key presses
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleChatKey.method_1436()) {
                chatVisible = !chatVisible;
                if (client.field_1724 != null) {
                    if (chatVisible) {
                        client.field_1724.method_7353(
                            class_2561.method_43470("§aChat GUI enabled"),
                            true
                        );
                    } else {
                        client.field_1724.method_7353(
                            class_2561.method_43470("§cChat GUI disabled"),
                            true
                        );
                    }
                }
            }
        });
    }
}
