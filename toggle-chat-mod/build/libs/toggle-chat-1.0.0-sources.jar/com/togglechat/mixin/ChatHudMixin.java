package com.togglechat.mixin;

import com.togglechat.ToggleChatMod;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_338.class)
public class ChatHudMixin {
    
    // In 1.21.11 Yarn mappings, ChatHud.render signature:
    // render(DrawContext context, TextRenderer textRenderer, int currentTick, int mouseX, int mouseY, boolean interactable, boolean bool)
    @Inject(method = "render(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/font/TextRenderer;IIIZZ)V", at = @At("HEAD"), cancellable = true)
    private void onRender(class_332 context, class_327 textRenderer, int currentTick, int mouseX, int mouseY, boolean interactable, boolean bool, CallbackInfo ci) {
        if (!ToggleChatMod.chatVisible) {
            ci.cancel();
        }
    }
}
